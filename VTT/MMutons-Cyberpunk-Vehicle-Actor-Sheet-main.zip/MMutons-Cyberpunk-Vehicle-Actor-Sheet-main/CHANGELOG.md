## 2.4
-You can now toggle an option in the settings that prevents losing permissions on an actor.
-There is now a info tab to take notes and write details about the vehicle.
-You can now set up bonuses and penalties per seat, which is managed by an Active Effect created in the occupant's sheet. (Edge-case warning, if you delete an unlinked token from the canvas without removing the occupant, the AE can get stuck. But don't worry, a hard-refresh cleans up all orphaned effects)

## 2.3
-Fixed VAS not appearing on Mook sheets.

## 2.2
- Removed redundant auto-detect vehicle upgrade code.

## 2.1
- Added non-English skill name matching.

## 2.0
- Initial release.
